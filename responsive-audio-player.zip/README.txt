A Pen created at CodePen.io. You can find this one at https://codepen.io/markhillard/pen/Hjcwu.

 This audio player features playlist support via JSON data and step navigation. The version you're seeing now is a fresh new take on this project... by modernizing the style and offloading all browser detection crap to a wonderful audio player plugin called Plyr (https://github.com/sampotts/plyr).